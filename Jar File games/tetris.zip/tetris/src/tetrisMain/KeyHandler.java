package tetrisMain;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener{
	tetris t;
	
	public KeyHandler(tetris t)
	{
		this.t = t;
	}
	
	@Override
	public void keyPressed(KeyEvent e) { 
		int keyPressed = e.getKeyCode();
		
		if(keyPressed == KeyEvent.VK_UP) { t.upPressed = true;}
		if(keyPressed == KeyEvent.VK_LEFT) { t.leftPressed = true;}
		if(keyPressed == KeyEvent.VK_RIGHT) { t.rightPressed = true;}
		if(keyPressed == KeyEvent.VK_DOWN) { t.downPressed = true;}
		if(keyPressed == KeyEvent.VK_SPACE) { t.spacePressed = true;}
	}

	@Override
	public void keyReleased(KeyEvent e) { 
		t.upPressed= false;
		t.leftPressed= false;
		t.rightPressed= false;
		t.downPressed= false;
		t.spacePressed = false;
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		
	}

	
}
