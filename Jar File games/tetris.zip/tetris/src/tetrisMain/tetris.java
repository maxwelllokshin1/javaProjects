package tetrisMain;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;
import javax.swing.Timer;

import tetrisMain.tetris.Node;

public class tetris extends JPanel implements ActionListener {
	public int screenWidth = window.width, screenHeight = window.height;

	public boolean upPressed, leftPressed, downPressed, rightPressed, spacePressed;

	KeyHandler keyH;

	int nx = window.scale * 5, ny = window.scale;
	int pWidth = window.scale, pHeight = window.scale;

	int gravityY = window.scale;
	int gravityX = window.scale;

	int FPS = 60;

	public Timer gameLoop;

	LinkedList<Block> blocks;

	Iterator<Block> itr;
	Block cur;
	
	int fallingSpeed = 20;
	int fallCounter = 0;
	int moveCounter = 0;
	tetrisMain.tetris.Block.Type currentType;

	public tetris() {
		setPreferredSize(new Dimension(screenWidth, screenHeight));
		setBackground(new Color(0, 0, 0));
		setFocusable(true);
		keyH = new KeyHandler(this);
		addKeyListener(keyH);

		blocks = new LinkedList<>();
		generateBlock();
		cur = blocks.getLast();

		startGameThread();
	}

	public void generateBlock() {
		int randBlock = (int) (Math.random() * 7);
		switch (randBlock) {
		case 0:
			currentType = Block.Type.O;
			break;
		case 1:
			currentType = Block.Type.I;
			break;
		case 2:
			currentType = Block.Type.S;
			break;
		case 3:
			currentType = Block.Type.Z;
			break;
		case 4:
			currentType = Block.Type.L;
			break;
		case 5:
			currentType = Block.Type.J;
			break;
		case 6:
			currentType = Block.Type.T;
			break;
		}
		blocks.add(new Block(nx, ny, currentType)); // Add a new block
	}

	@Override
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		drawGameScreen(g);
		

	}

	public void drawGameScreen(Graphics g) {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 20; j++) {
				g.setColor(Color.DARK_GRAY);
				g.fillRect(i * window.scale, j * window.scale, window.scale - 1, window.scale - 1);
			}
		}
		
		for (Block b : blocks) {
			for (Node n : b.nodes) {
				g.setColor(b.color);
				g.fillRect(n.x, n.y, window.scale - 1, window.scale - 1);
			}
		}
		
	}
	
	public void startGameThread()
	{
		gameLoop = new Timer(1000 / FPS, this);
		gameLoop.start();
	}

	int change = 0;
	
	
//	public void move() {
//		fallCounter++;
//		if(fallCounter % 2 == 0)
//		{
//			if (leftPressed) {
//				cur.move(-gravityX, 0);
//			}
//			if (rightPressed) {
//				cur.move(gravityX, 0);
//			}
//		}
//		if(fallCounter % 5 == 0)
//		{
//			if (upPressed) {
//				cur.rotate(); // Rotate block on up arrow press
//			}
//			if (spacePressed)
//			{
//				while(canMoveDown(cur))
//				{
//					cur.move(0, gravityY);
//				}
//			}
//		}
//		if(fallCounter >= fallingSpeed)
//		{
//			if (canMoveDown(cur)) {
//				cur.move(0, gravityY);
//			}else {
//				blocks.add(cur);
//				generateBlock();
//				cur = blocks.getLast();
//			}
//			fallCounter = 0;
//		}
//		
//		if (downPressed) {
//			cur.move(0, gravityY);
//		}
//		
//		checkEdges();
//		
//		
//	}
	
	public void move() {
	    fallCounter++;
	    moveCounter++;
	    if (moveCounter % 2 == 0) {
	        if (leftPressed) {
	            cur.move(-gravityX, 0);
	        }
	        if (rightPressed) {
	            cur.move(gravityX, 0);
	        }
	    }
	    if (moveCounter % 2 == 0) {
	        if (upPressed) {
	            cur.rotate(); // Rotate block on up arrow press
	        }
	        if (spacePressed) {
	            while (canMoveDown(cur)) {
	                cur.move(0, gravityY);
	            }
	        }
	    }
	    if (fallCounter >= fallingSpeed) {
	        if (canMoveDown(cur)) {
	            cur.move(0, gravityY);
	        } else {
	            blocks.add(cur);
	            generateBlock();
	            cur = blocks.getLast();
	            clearFilledRows(); // Check and clear filled rows
	            increaseSpeed(); // Increase speed after clearing a row
	        }
	        fallCounter = 0;
	    }

	    if (downPressed) {
	        cur.move(0, gravityY);
	    }

	    checkEdges();
	}

	public void clearFilledRows() {
	    
	}


	public void increaseSpeed() {
	    // Increase falling speed every time a row is cleared
	    if (fallingSpeed > 5) { // Ensure the speed doesn't go below a limit
	        fallingSpeed -= 1;
	    }
	    fallingSpeed -= 1;
	}

	public void checkEdges() {
	    int minX = Integer.MAX_VALUE;
	    int maxX = Integer.MIN_VALUE;
	    int minY = Integer.MAX_VALUE;
	    int maxY = Integer.MIN_VALUE;

	    for (Node n : cur.nodes) {
	        if (n.x < minX) {
	            minX = n.x;
	        }
	        if (n.x > maxX) {
	            maxX = n.x;
	        }
	        if (n.y < minY) {
	            minY = n.y;
	        }
	        if(n.y > maxY)
	        {
	        	maxY = n.y;
	        }
	    }

	    // Check if the block is off the left edge
	    if (minX < 0) {
	        int offset = 0 - minX;
	        cur.move(offset, 0);
	    }
	    // Check if the block is off the right edge
	    if (maxX > screenWidth - window.scale) {
	        int offset = screenWidth - window.scale - maxX;
	        cur.move(offset, 0);
	    }
	    // Check if the block is off the top edge
	    if (minY < 0) {
	        gameLoop.stop(); // Game over if the block goes past the top
	    }
	    if (maxY > screenHeight - window.scale) {
	    	int offset = screenHeight - window.scale - maxY;
	        cur.move(0, offset);
	    }
	}

	public boolean canMoveDown(Block cur) {
//		if (n.y >= screenHeight - window.scale) {
//            return false; // Block hits the bottom of the screen.
//        }
	    for (Node n : cur.nodes) {
	        for (Block b : blocks) {
	            if (b != cur) { // Don't check against itself.
	                for (Node nb : b.nodes) {
	                    if (collision(n, nb)) { // Check if it collides with another block.
	                        return false;
	                    }
	                }
	            }
	        }
	    }
	    return true; // No collision, can move down.
	}


	public boolean collision(Node n, Node nodeLayer) {
		
		int minX = Integer.MAX_VALUE;
	    int maxX = Integer.MIN_VALUE;
	    int minY = Integer.MAX_VALUE;
	    int maxY = Integer.MIN_VALUE;

	    for (Node curN : cur.nodes) {
	        if (curN.x < minX) {
	            minX = curN.x;
	        }
	        if (curN.x > maxX) {
	            maxX = n.x;
	        }
	        if (curN.y < minY) {
	            minY = curN.y;
	        }
	        if(curN.y > maxY)
	        {
	        	maxY = curN.y;
	        }
	    }
	    
	    // Check if the current node is colliding with another node.
	    return n.x < nodeLayer.x + nodeLayer.width && n.x + n.width > nodeLayer.x
	            && n.y < nodeLayer.y + (nodeLayer.height*3) && n.y + (n.height*3) > nodeLayer.y;
	}


	public class Node {
		int x, y;
		int width = pWidth, height = pHeight;

		public Node(int nx, int ny) {
			x = nx;
			y = ny;
		}
	}

	public class Block {
		enum Type {
			O, I, S, Z, L, J, T
		}

		LinkedList<Node> nodes;
		Color color;

		public Block(int nx, int ny, Type type) {
			nodes = new LinkedList<>();
			switch (type) {
			case I:
				nodes.add(new Node(nx, ny));
				nodes.add(new Node(nx + pWidth, ny));
				nodes.add(new Node(nx + (pWidth * 2), ny));
				nodes.add(new Node(nx - pWidth, ny));
				color = Color.CYAN;
				break;
			case J:
				nodes.add(new Node(nx, ny));
				nodes.add(new Node(nx + pWidth, ny));
				nodes.add(new Node(nx - pWidth, ny));
				nodes.add(new Node(nx - pWidth, ny - pHeight));
				color = Color.BLUE;
				break;
			case L:
				nodes.add(new Node(nx, ny));
				nodes.add(new Node(nx - pWidth, ny));
				nodes.add(new Node(nx + pWidth, ny));
				nodes.add(new Node(nx + pWidth, ny - pHeight));
				color = Color.ORANGE;
				break;
			case O:
				nodes.add(new Node(nx, ny));
				nodes.add(new Node(nx + pWidth, ny));
				nodes.add(new Node(nx, ny + pHeight));
				nodes.add(new Node(nx + pWidth, ny + pHeight));
				color = Color.YELLOW;
				break;
			case S:
				nodes.add(new Node(nx, ny));
				nodes.add(new Node(nx - pWidth, ny));
				nodes.add(new Node(nx, ny - pHeight));
				nodes.add(new Node(nx + pWidth, ny - pHeight));
				color = Color.GREEN;
				break;
			case T:
				nodes.add(new Node(nx, ny));
				nodes.add(new Node(nx - pWidth, ny));
				nodes.add(new Node(nx + pWidth, ny));
				nodes.add(new Node(nx, ny - pHeight));
				color = Color.MAGENTA;
				break;
			case Z:
				nodes.add(new Node(nx, ny));
				nodes.add(new Node(nx + pWidth, ny));
				nodes.add(new Node(nx, ny - pHeight));
				nodes.add(new Node(nx - pWidth, ny - pHeight));
				color = Color.RED;
				break;
			}
		}

		public void move(int dx, int dy) {
			for (Node n : nodes) {
				n.x += dx;
				n.y += dy;
			}
		}
		public void rotate() {
		    switch (currentType) {
		        case O:
		            break; // No rotation needed for "O" shape
		        default:
		            int pivotX = nodes.get(0).x;
		            int pivotY = nodes.get(0).y;
		            for (Node n : nodes) {
		                int dx = n.x - pivotX;
		                int dy = n.y - pivotY;
		                n.x = pivotX - dy;
		                n.y = pivotY + dx;
		            }
		            break;
		    }
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		move();
		repaint();

	}
}
