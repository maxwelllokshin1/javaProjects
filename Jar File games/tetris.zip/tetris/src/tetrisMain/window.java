package tetrisMain;

import java.awt.Dimension;

import javax.swing.JFrame;

public class window {
	public static JFrame window;
	public static int scale = 40;
	public static int width = scale*10, height = scale * 20;
	
	
	public static void main(String[] args)
	{
		window = new JFrame("Tetris");
		window.setMinimumSize(new Dimension(width, height));
		window.setResizable(true);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		tetris t = new tetris();
		window.add(t);
		window.pack();
		
		window.setLayout(null);
		window.setLocationRelativeTo(null);
		window.setVisible(true);
	}
}
