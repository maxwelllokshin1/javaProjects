package Main;

import java.awt.Dimension;

import javax.swing.JFrame;

public class mainWindow{
	public static int screenWidth = 320;
	public static int screenHeight = 720;
	public static void main(String[] args) throws Exception
	{
		JFrame window = new JFrame("Lava Jumper");
		window.setMinimumSize(new Dimension(screenWidth, screenHeight));
		window.setResizable(false);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		LJumperGame ljg = new LJumperGame();
		window.add(ljg);
		window.pack();
		
		window.setLocationRelativeTo(null);
		window.setVisible(true);
	}
}
