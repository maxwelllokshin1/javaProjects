package Main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import Main.LJumperGame;

public class actions implements ActionListener, KeyListener{
	LJumperGame ljg;
	public actions(LJumperGame ljg)
	{
		this.ljg = ljg;
	}
	@Override
	public void keyPressed(KeyEvent e) {
		if(ljg.screen == ljg.gameScreen)
		{
			if (e.getKeyCode() == KeyEvent.VK_UP)
				ljg.upPressed = true;
			if (e.getKeyCode() == KeyEvent.VK_LEFT)
				ljg.velocityX = -(mainWindow.tile * 2);
			if (e.getKeyCode() == KeyEvent.VK_RIGHT)
				ljg.velocityX = mainWindow.tile * 2;
			if (e.getKeyCode() == KeyEvent.VK_DOWN)
				ljg.velocityY += 5;
		}
		
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			if(ljg.screen == ljg.gameStartScreen)
			{
				ljg.placeAllRocks.start();
				ljg.gameLoop.start();
				ljg.screen = ljg.gameScreen;
			}
			if (ljg.gameOver) {
				ljg.resetGame();
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (!ljg.gameOver) {
			ljg.move();
		} else {
			ljg.placeAllRocks.stop();
			ljg.gameLoop.stop();
		}
		ljg.repaint();
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {
		ljg.upPressed = false;
		ljg.velocityX = 0;
		if(e.getKeyCode() == KeyEvent.VK_DOWN)
		{
			ljg.velocityY = 0;
		}
	}
}
