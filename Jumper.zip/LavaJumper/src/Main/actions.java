package Main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class actions implements ActionListener, KeyListener {
    private LJumperGame ljg;

    public actions(LJumperGame ljg) {
        this.ljg = ljg;

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (ljg.screen == ljg.gameScreen) {
            int keyCode = e.getKeyCode();

            // Handle movement (UP, LEFT, RIGHT, DOWN)
            if (keyCode == KeyEvent.VK_UP) {
                ljg.upPressed = true;
            } else if (keyCode == KeyEvent.VK_LEFT) {
                ljg.velocityX = -(mainWindow.tile * 2);
            } else if (keyCode == KeyEvent.VK_RIGHT) {
                ljg.velocityX = mainWindow.tile * 2;
            } else if (keyCode == KeyEvent.VK_DOWN) {
                ljg.velocityY += 5;  // Add downward velocity when DOWN key is pressed
                ljg.downPressed = true;
            }
        }

        // Start the game when ENTER is pressed
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            if (ljg.screen == ljg.gameStartScreen) {
                ljg.placeAllRocks.start();
                ljg.gameLoop.start();
                ljg.screen = ljg.gameScreen;
            }
            if (ljg.screen == ljg.gameOverScreen) {
                resetGame();  // Reset the game on ENTER from the Game Over screen
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!ljg.gameOver) {
            ljg.move();  // Move the player and update the game state
        } else {
            ljg.placeAllRocks.stop();
            ljg.gameLoop.stop();
        }
        ljg.repaint();  // Redraw the screen
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // No action needed on key typed in this game context
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Handle key release for stopping movements
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            ljg.upPressed = false;
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            ljg.downPressed = false;
            ljg.velocityY = 0;  // Reset downward velocity when DOWN is released
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_RIGHT) {
            ljg.velocityX = 0;  // Stop horizontal movement when arrow keys are released
        }
    }

    // Reset the game
    public void resetGame() {
        ljg.placeAllRocks.stop();
        ljg.gameLoop.stop();

        // Clear all rocks and reset score, player position, etc.
        ljg.rocks.clear();
        ljg.score = 0;
        ljg.jumped = 0;
        ljg.velocityY = 0;
        ljg.screen = ljg.gameScreen;
        ljg.gameOver = false;

        // Reinitialize player (null indicates the player needs to be created again)
        ljg.p = null;

        // Restart timers
        ljg.gameLoop.start();
        ljg.placeAllRocks.start();
    }
}