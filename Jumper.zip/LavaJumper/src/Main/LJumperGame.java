package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Iterator;
import java.util.LinkedList;
import javax.swing.JPanel;
import javax.swing.Timer;

public class LJumperGame extends JPanel implements ActionListener {
    public boolean upPressed, leftPressed, rightPressed, downPressed;
    public final int screenWidth = mainWindow.screenWidth;
    public final int screenHeight = mainWindow.screenHeight;

    // PLAYER
    public final int pWidth = mainWindow.tile * mainWindow.tile, pHeight = pWidth;
    public int px, py;

    // ROCK
    public final int rWidth = mainWindow.tile*8, rHeight = rWidth;
    public final int rockGrav = mainWindow.tile ;

    // LOGIC
    public Player p;
    public int velocityX = 0, velocityY = 0, gravity = 1;

    public LinkedList<Rocks> rocks;

    // TIME
    public Timer gameLoop;
    public Timer placeAllRocks;

    public int score = 0;
    public boolean gameOver = false;
    public int jumped = 0;

    // GAME SCREENS
    public int screen = 0;
    public int gameStartScreen = 0, optionsScreen = 1, gameScreen = 2, gameOverScreen = 3;

    public int FPS = 60;

    actions a;
    TitleScreen titleScreen;
    EndScreen endScreen;

    String text = "";

    public LJumperGame() {
        screen = gameStartScreen;
        setPreferredSize(new Dimension(screenWidth, screenHeight));
        setBackground(Color.black);
        setFocusable(true);
        a = new actions(this);
        addKeyListener(a);

        // Mouse Listeners
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            	LJumperGame.this.mousePressed(e);  // Handle mouse press (e.g., restart game)
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	LJumperGame.this.mouseReleased(e);  // Handle mouse press (e.g., restart game)
            }
        });

//        addMouseMotionListener(new MouseMotionAdapter() {
//            @Override
//            public void mouseDragged(MouseEvent e) {
//                mouseDragged(e); // Handle mouse dragging (e.g., move UI elements)
//            }
//        });

        rocks = new LinkedList<>();

        // Timer for placing rocks every 500 ms
        placeAllRocks = new Timer(1500, e -> placeRocks());

        // Main game loop timer
        gameLoop = new Timer(1000 / FPS, this);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Render different screens based on the current state
        if (screen == gameStartScreen) {
            titleScreen = new TitleScreen(g, this);
            titleScreen.UI();
        } else if (screen == gameScreen) {
            drawGameScreen(g);
        } else if (screen == gameOverScreen) {
            endScreen = new EndScreen(g, this);
            endScreen.UI();
        }
    }

    private void drawGameScreen(Graphics g) {
    	
    	g.setColor(Color.RED);
    	g.fillRect(100, 100, rWidth, rHeight);
    	
        g.setColor(Color.GRAY);
        for (Rocks rock : rocks) {
            g.fillRect(rock.x, rock.y, rock.width, rock.height);
        }

        if (p != null) {
            // PLAYER
            g.setColor(Color.BLUE);
            g.fillRect(p.x, p.y, p.width, p.height);
        }
    }

    public void move() {
        if (jumped == 0 && !rocks.isEmpty()) {
            Rocks firstRock = rocks.getFirst();
            if (p == null) {
                p = new Player(firstRock.x + (firstRock.width / mainWindow.tile),
                        firstRock.y + (firstRock.height / mainWindow.tile));
            }
            p.y = firstRock.y + (firstRock.height / mainWindow.tile);
            if (p.x < firstRock.x || p.x > firstRock.x + firstRock.width || downPressed) {
                jumped = 1;
                velocityY = rockGrav;
            }
        }
        if (p != null) {
            // PLAYER physics
            velocityY += gravity;
            p.y += velocityY;

            if (jumped != 0) {
                if (p.y + pHeight < 0) {
                    gameOver = true;
                    screen = gameOverScreen;
                }
            }

            p.x += velocityX;

            // Keep player within bounds
            if (p.x > screenWidth) p.x = 0;
            if (p.x < 0) p.x = screenWidth - pWidth;

            Iterator<Rocks> rockIterator = rocks.iterator();
            while (rockIterator.hasNext()) {
                Rocks rock = rockIterator.next();
                rock.y += rockGrav;
                if (collision(p, rock)) {
                    velocityY = rockGrav;

                    if (upPressed) {
                        if (!rock.passed) {
                            score++;
                        }
                        jumped = 1;
                        rock.passed = true;
                        velocityY = -25; // Jump
                    }
                }

                // Remove off-screen rocks
                if (rock.y > screenHeight) {
                    rockIterator.remove();
                }
            }

            if (p.y > screenHeight) {
                gameOver = true;
                screen = gameOverScreen;
            }
        }
    }

    private void placeRocks() {
        int randX = (int) (Math.random() * (screenWidth - rWidth));
        rocks.add(new Rocks(randX, -rHeight)); // Place new rock
    }

    private boolean collision(Player p, Rocks r) {
        return p.x < r.x + r.width && p.x + p.width > r.x && p.y < r.y + r.height && p.y + p.height > r.y;
    }

    // Mouse Event Handling
    private void mousePressed(MouseEvent e) {
        int mouseX = e.getX() / 50;
        int mouseY = e.getY()/ 50;

        if (screen == gameScreen) {
        	if(mouseX == (100/50) && mouseY == (100/50))
            {
            	System.out.println("HIT");
            }
        	checkRock(mouseX,mouseY);
        }
        
        System.out.println(mouseX + " " + mouseY);
    }

    private void mouseDragged(MouseEvent e) {
        // Handle mouse drag behavior (for example, dragging UI elements)
    }

    private void mouseReleased(MouseEvent e) {
        // Handle mouse release behavior (for example, stop dragging UI elements)
    }
    
    private void checkRock(int mouseX, int mouseY)
    {
    	Iterator<Rocks> rockIterator = rocks.iterator();
        while (rockIterator.hasNext()) {
            Rocks rock = rockIterator.next();
            //System.out.println("ROCK - " +((rock.x/50)-1)+ " " + ((rock.x/50)+1) + " " + ((rock.y/50)-1) + " " + ((rock.y/50)+1));
            
        }
    }

    // Check if mouse is within certain area (e.g., restart button)
    private boolean isMouseWithinBounds(int mouseX, int mouseY) {
        int buttonX = 100;  // Example position
        int buttonY = 100;
        int buttonWidth = 200;
        int buttonHeight = 50;

        return (mouseX >= buttonX && mouseX <= buttonX + buttonWidth &&
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight);
    }

    // Reset the game
    public void resetGame() {
        placeAllRocks.stop();
        gameLoop.stop();

        // Clear rocks, reset score, and other variables
        rocks.clear();
        score = 0;
        jumped = 0;
        velocityY = 0;
        screen = gameScreen;
        gameOver = false;

        // Reinitialize player
        p = null;

        // Restart timers
        gameLoop.start();
        placeAllRocks.start();
    }

    // Player class
    class Player {
        int x, y;
        int width = pWidth, height = pHeight;

        Player(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    // Rock class
    class Rocks {
        int x, y;
        int width = rWidth, height = rHeight;
        boolean passed = false;

        Rocks(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameOver) {
            move(); // Update player and game state
        }
        repaint(); // Redraw screen
    }

    public int getXforCenteredText(String text, Graphics g) {
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        return screenWidth / 2 - length / 2; // Center the text horizontally
    }
}