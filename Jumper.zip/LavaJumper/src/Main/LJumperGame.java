package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class LJumperGame extends JPanel implements ActionListener, KeyListener {
	public boolean upPressed, leftPressed, rightPressed, enterPressed;
	int screenWidth = mainWindow.screenWidth;
	int screenHeight = mainWindow.screenHeight;

	// PLAYER
	int pWidth = 25, pHeight = 25;
	int px = (screenWidth - pWidth) / 2, py = pHeight-screenHeight;

	class Player {
		int x = px;
		int y = py;
		int width = pWidth;
		int height = pHeight;

	}

	// ROCK
	int rWidth = 40, rHeight = 40;
	int rx = 0, ry = -rHeight;

	// int spaceBetweenRocks = -rHeight*3;
	class Rocks {
		int x = rx;
		int y = ry;
		int width = rWidth;
		int height = rHeight;

		boolean passed = false;

	}

	// LOGIC
	Player p;
	int velocityX = 0;
	int velocityY = 0;
	int gravity = 1;

	// ROCK LOGIC
	int randGrav;

	ArrayList<Rocks> r;

	Timer gameLoop;
	Timer placeAllRocks;
	boolean gameOver = false;
	int score = 0;

	LJumperGame() {
		setPreferredSize(new Dimension(screenWidth, screenHeight));
		setBackground(Color.black);

		setFocusable(true);
		addKeyListener(this);

		p = new Player();
		r = new ArrayList<Rocks>();

		// PLACE ALL ROCKS
		placeAllRocks = new Timer(750, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				placeRocks();
			}
		});

		placeAllRocks.start();
		// game timer
		gameLoop = new Timer(1000 / 60, this);
		gameLoop.start();

	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		draw(g);
	}

	public void draw(Graphics g) {

		for (int i = 0; i < r.size(); i++) {
			Rocks rock = r.get(i);
			g.setColor(Color.GRAY);
			g.fillRect(rock.x, rock.y, rock.width, rock.height);
		}

		// PLAYER
		g.setColor(Color.BLUE);
		g.fillRect(p.x, p.y, p.width, p.height);

	}

	public void move() {

		
//		if(score >= 1)
//		{
			// PLAYER
			velocityY += gravity;
			p.y += velocityY;
			if (p.y >= (screenHeight - (p.width * 2))) {
				p.y = screenHeight - (p.width * 2);
			} else if (p.y <= p.height) {
				p.y = p.height;
			} else {
				p.y = p.y;
			}

			p.x += velocityX;

			if (p.x > (screenWidth - (p.width / 2))) {
				p.x = 0;
			} else if (p.x < 0) {
				p.x = (screenWidth - (p.width / 2));
			} else {
				p.x = p.x;
			}
		//}
		
		
		for (int i = 0; i < r.size(); i++) {
			Rocks indivRock = r.get(i);
			randGrav = 10;
			indivRock.y += randGrav;

//			if(!indivRock.passed && indivRock.y >= screenHeight)
//			{
//				indivRock.passed = true;
//				//first = 1;
//				score += 1;
//				System.out.println("Score: " + score);
//			}			

			if (collision(p, indivRock)) {
				// p.y = indivRock.y;
				velocityY = randGrav;

				if (upPressed == true) {
					if(!indivRock.passed)
					{
						score += 1;
						System.out.println("Score: " + score);
					}
					indivRock.passed = true;
					velocityY = -25;
				}
			}
		}

	}

	public void placeRocks() {

		int randX = (int) (Math.random() * (screenWidth - (rWidth * 2)) + rWidth / 2);
		Rocks rock = new Rocks();
		rock.x = randX;
		r.add(rock);
	}

	public boolean collision(Player p, Rocks r) {

		return p.x < r.x + r.width && p.x + p.width > r.x && p.y < r.y + r.height && p.y + p.height > r.y;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			upPressed = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			velocityX = -10;
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			velocityX = 10;
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		move();
		repaint();
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {
		upPressed = false;
		velocityX = 0;
	}

}
