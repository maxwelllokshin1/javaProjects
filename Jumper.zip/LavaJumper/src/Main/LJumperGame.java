package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class LJumperGame extends JPanel implements Runnable, ActionListener  {
	public boolean upPressed, leftPressed, rightPressed;
	public final int screenWidth = mainWindow.screenWidth;
	public final int screenHeight = mainWindow.screenHeight;

	// PLAYER
	public final int pWidth = mainWindow.tile * mainWindow.tile, pHeight = pWidth;
	public int px, py;

	// ROCK
	public final int rWidth = (pWidth * 3) / 2, rHeight = rWidth;
	public final int rockGrav = mainWindow.tile * 2;

	// LOGIC
	public Player p;
	public int velocityX = 0, velocityY = 0, gravity = 1;

	private LinkedList<Rocks> rocks;

	// TIME
	public Timer gameLoop;
	public Timer placeAllRocks;
	public Thread gameThread;

	public int score = 0;
	public boolean gameOver = false;
	public int jumped = 0;

	// GAME SCREENS
	public int screen = 0;
	public int gameStartScreen = 0, optionsScreen = 1, gameScreen = 2;
	
	public int blink = 1;
	public int counter = 0;
	
	
	public int FPS = 60;
	
	actions a;
	
	String text = "";

	LJumperGame() {
		setPreferredSize(new Dimension(screenWidth, screenHeight));
		setBackground(Color.black);
		setFocusable(true);
		a = new actions(this);
		addKeyListener(a);

		rocks = new LinkedList<>();
		
		// PLACE ALL ROCKS every 750 ms
		placeAllRocks = new Timer(500, e -> placeRocks());

		// Main game timer
		gameLoop = new Timer(1000 / FPS, this);

	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		draw(g);
	}

	public void draw(Graphics g) {
		g.setColor(Color.white);
		g.setFont(new Font("Arial", Font.BOLD, 32));
		
		if(screen == gameStartScreen)
		{
			text = "HOP";
			g.drawString(text, getXforCenteredText(text, g), screenHeight/2);
			if(blink == 1)
			{
				text = "[Press ENTER]";
				g.drawString(text, getXforCenteredText(text, g), screenHeight/2 + (50));
			}
		}else if(screen == gameScreen)
		{
			g.setColor(Color.GRAY);
			for (Rocks rock : rocks) {
				g.fillRect(rock.x, rock.y, rock.width, rock.height);
			}

			if (p != null) {
				// PLAYER
				g.setColor(Color.BLUE);
				g.fillRect(p.x, p.y, p.width, p.height);
			}
		}

		// SCORE
		if (gameOver) {
			g.setColor(Color.white);
			g.setFont(g.getFont().deriveFont(Font.PLAIN, 30F));
			text = "Game Over: " + String.valueOf((int) score);
			g.drawString(text, getXforCenteredText(text, g), screenHeight/2);
			g.setFont(g.getFont().deriveFont(Font.PLAIN, 20F));
			if(blink == 1)
			{
				text = "[Press ENTER]";
				g.drawString(text, getXforCenteredText(text, g), screenHeight/2 + (50));
			}
		}

	}
	public void setUpGame()
	{
		screen = gameStartScreen;
	}
	public void startGameThread()
	{
		gameThread = new Thread();
		gameThread.start();
	}
	
	@Override
	public void run() {
		double drawInterval = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		
		long timer = 0;
		int drawCount = 0;
		
		while(gameThread != null)
		{
			currentTime = System.nanoTime();
			delta += (currentTime - lastTime) / drawInterval;
			
			timer += (currentTime-lastTime);
			lastTime = currentTime;
			
			if(delta >= 1)
			{
				update();
				repaint();
				delta--;
				drawCount++;
			}
			if(timer >= 1000000000)
			{
				drawCount = 0;
				timer = 0;
			}
		}
	}
	
	private void update()
	{
		System.out.println("Counter: " + counter);
		counter++;
		if(counter > 12)
		{
			if(blink == 1)
			{
				blink = 2;
			}else if(blink == 2)
			{
				blink = 1;
			}
			counter = 0;
		}
	}
	
	private int getXforCenteredText(String text, Graphics g)
	{
		int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
		return screenWidth/2 - length/2;
	}

	public void move() {
		if (jumped == 0 && !rocks.isEmpty()) {
			Rocks firstRock = rocks.getFirst();
			if (p == null) {
				p = new Player(firstRock.x + (firstRock.width / mainWindow.tile),
						firstRock.y + (firstRock.height / mainWindow.tile));
			}
			p.y = firstRock.y + (firstRock.height / mainWindow.tile);
		}
		if (p != null) {
			// PLAYER
			velocityY += gravity;
			p.y += velocityY;

			// p.y = Math.min(p.y, screenHeight - (p.width * 2));
			if (jumped != 0) {
				if(p.y + pHeight < 0)
				{
					gameOver = true;
				}
			}

			p.x += velocityX;

			// Keep player within bounds
			if (p.x > screenWidth)
				p.x = 0;
			if (p.x < 0)
				p.x = screenWidth - pWidth;

			Iterator<Rocks> rockIterator = rocks.iterator();

			while (rockIterator.hasNext()) {
				Rocks rock = rockIterator.next();
				rock.y += rockGrav;
				if (collision(p, rock)) {
					velocityY = rockGrav;

					if (upPressed) {
						if (!rock.passed) {
							score++;
						}
						jumped = 1;
						rock.passed = true;
						velocityY = -25; // jump
					}
				}

				// remove off-screen rocks
				if (rock.y > screenHeight) {
					rockIterator.remove();
				}
			}

			if (p.y > screenHeight) {
				gameOver = true;
			}
		}

	}

	private void placeRocks() {

		int randX = (int) (Math.random() * (screenWidth - rWidth));
		rocks.add(new Rocks(randX, -rHeight));

	}

	private boolean collision(Player p, Rocks r) {

		return p.x < r.x + r.width && p.x + p.width > r.x && p.y < r.y + r.height && p.y + p.height > r.y;
	}

	

	// Player class
	class Player {
		int x, y;
		int width = pWidth, height = pHeight;

		Player(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}

	// Rock class
	class Rocks {
		int x, y;
		int width = rWidth, height = rHeight;
		boolean passed = false;

		Rocks(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}
	
	public void resetGame()
	{
		placeAllRocks.stop();
		gameLoop.stop();
		
		// clear all rocks and reset score
		rocks.clear();
		score = 0;
		jumped = 0;
		velocityY = 0;
		gameOver = false;
		
		// Reinitialize player
		p = null;
		
		// Restart timers
		gameLoop.start();
		placeAllRocks.start();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		a.actionPerformed(e);
	}
}