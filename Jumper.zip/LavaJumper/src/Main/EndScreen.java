package Main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class EndScreen {
	// Shows all options for end screen
	// UI
	// Player stats 
	
	Graphics g;
	LJumperGame ljg;

	int blink = 1;
	int counter = 0;
	
	public EndScreen(Graphics g, LJumperGame ljg)
	{
		this.g = g;
		this.ljg = ljg;
	}
	
	public void UI()
	{
		g.setColor(Color.GRAY);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 30F));
		ljg.text = "Game Over: " + String.valueOf((int) ljg.score);
		g.drawString(ljg.text, ljg.getXforCenteredText(ljg.text, g), ljg.screenHeight/2);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 20F));
		if(blink == 1)
		{
			ljg.text = "[Press ENTER]";
			g.drawString(ljg.text, ljg.getXforCenteredText(ljg.text, g), ljg.screenHeight/2 + (50));
		}
	}
}
