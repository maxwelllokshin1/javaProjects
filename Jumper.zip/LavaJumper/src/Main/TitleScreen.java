package Main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class TitleScreen {
	// Title name
	// options screen
	// choose class
	// exit game
	
	Graphics g;
	LJumperGame ljg;
	
	int blink = 1;
	int counter = 0;
	
	public TitleScreen(Graphics g, LJumperGame ljg)
	{
		this.g = g;
		this.ljg = ljg;
	}
	
	public void UI()
	{
		g.setColor(Color.GRAY);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 30F));
		ljg.text = "HOP";
		g.drawString(ljg.text, ljg.getXforCenteredText(ljg.text, g), ljg.screenHeight/2);
		if(blink == 1)
		{
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 20F));
			ljg.text = "[Press ENTER]";
			g.drawString(ljg.text, ljg.getXforCenteredText(ljg.text, g), ljg.screenHeight/2 + (50));
		}
	}
}
