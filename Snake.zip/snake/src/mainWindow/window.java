package mainWindow;

import java.awt.Dimension;

import javax.swing.JFrame;

public class window {
	public static JFrame window;
	public static int scale = 25;
	public static int boardWidth = scale * 25;
	public static int boardHeight = scale * 25;
	public static void main(String[] args)
	{
		window = new JFrame("Snake");
		
		window.setMinimumSize(new Dimension(boardWidth, boardHeight));
		window.setResizable(false);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mechanics m = new mechanics();
		window.add(m);
		window.pack();
		
		window.setLayout(null);
		window.setLocationRelativeTo(null);
		window.setVisible(true);
	}
}
