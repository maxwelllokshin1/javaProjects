package mainWindow;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import mainWindow.mechanics.Player;


public class mechanics extends JPanel implements ActionListener{
	public int screenWidth = window.boardWidth;
	public int screenHeight = window.boardHeight;
	public boolean upPressed, leftPressed, downPressed, rightPressed;
	public Timer gameLoop;

    public int FPS = 120;
    
    keyH keyHandler;
    int pWidth = window.scale, pHeight = window.scale;
    int px = window.scale*5, py = window.scale*6;
    
    final int rWidth = window.scale, rHeight = window.scale;
    
    boolean captured = true;
    LinkedList<Player> snake;
        
    double velocity = 5.0;
    double dx = 0, dy= 0;
    
    int score = 0;
	
    boolean gameOver = false;
    
	public mechanics()
	{
        setPreferredSize(new Dimension(screenWidth, screenHeight));
        setBackground(Color.BLACK);
        setFocusable(true);
        keyHandler = new keyH(this);
        addKeyListener(keyHandler);
        
        snake = new LinkedList<>();
        snake.add(new Player(px, py));
        
        gameLoop = new Timer(1000/FPS, this);
        gameLoop.start();
	}
	
	@Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGameScreen(g);
    }
	
	public void drawGameScreen(Graphics g)
	{
		if(gameOver)
		{
			drawGameOverScreen(g);
		}
		g.setColor(new Color(255,255,255,255));
		g.setFont(getFont().deriveFont(30F));
		g.drawString("SCORE: " + score, window.scale, window.scale*2);
		
		if(r != null)
		{	
			g.setColor(new Color(255,0,0,255));
			g.fillRect(r.x, r.y, r.width, r.height);
		}
		
		for(Player segment : snake)
		{
//			if(segment != snake.getFirst())
//			{
//				g.setColor(new Color(0,255,0,255));
//			}else
//			{
//				g.setColor(new Color(100,255,255,255));
//			}
			g.setColor(new Color(0,255,0,255));
			g.fillRect(segment.x, segment.y, segment.width, segment.height);
		}
	}
	
	public void drawGameOverScreen(Graphics g)
	{
		g.setColor(new Color(255,255,255,255));
		g.setFont(getFont().deriveFont(50F));
		g.drawString("[GAME OVER]", getXforCenteredText("[GAME OVER]", g), screenHeight/2);
		
		gameLoop.stop();
	}
	
	public void move()
	{
		placeRed();
		if(upPressed) {dy = -velocity; dx = 0;}
		else if(downPressed) {dy = velocity; dx = 0; }
		else if(leftPressed) {dx = -velocity; dy = 0; }
		else if(rightPressed) {dx = velocity; dy = 0; }
		
		Player head = snake.getFirst();
		if(upPressed || downPressed) {head.x = closestCoord(head.x);}
		else if(leftPressed || rightPressed) {head.y = closestCoord(head.y);}

		moveSnake();
		
		if(collision(snake.getFirst(),r))
		{
			r = null;
			//captured = true;
			addSegments(10);
			score += 1;
		}
	}
	
	public void moveSnake()
	{
		LinkedList<Player> newSnake = new LinkedList<>();
		
		Player head = snake.getFirst();
		Player newHead = new Player(head.x + (int) dx, head.y + (int) dy);
		
		newSnake.add(newHead);
		
		for(int i = 0; i<snake.size()-1; i++)
		{
			Player currentSegment = snake.get(i);
//	        Player nextSegment = snake.get(i + 1);
//	        
//	        // Move each segment to the position of the previous segment
//	        currentSegment.x = nextSegment.x;
//	        currentSegment.y = nextSegment.y;

	        // Add the updated segment to the new snake
	        newSnake.add(currentSegment);
		}
		
		snake = newSnake;
		
		for(Player segment : snake)
		{
			if(upPressed || downPressed) {segment.x = closestCoord(segment.x);}
			else if(leftPressed || rightPressed) {segment.y = closestCoord(segment.y);}
		}
		
		checkSnakeCollision();
		
		if(gameOver)
		{
			
		}
	}
	
	public void addSegments(int count)
	{
		Player lastSegment = snake.getLast();
		int lastX = lastSegment.x;
		int lastY = lastSegment.y;
		for(int i = 0; i<count; i++)
		{
//			if(upPressed)
//			{
//				lastY+=pHeight;
//			}else if(downPressed)
//			{
//				lastY-=pHeight;
//			}else if(leftPressed)
//			{
//				lastX+=pWidth;
//			}else if(rightPressed)
//			{
//				lastX-=pWidth;
//			}
			snake.add(new Player(lastX, lastY));
		}
	}
	
	public int closestCoord(int coord)
	{
		return Math.round(coord / 25.0f) * window.scale;
	}
	
	Player r;
	
	public void placeRed()
	{
		if(r == null)
		{
			int randX = (int) (Math.random() * (screenWidth/window.scale)) * window.scale;
			int randY = (int) (Math.random() * (screenHeight/window.scale)) * window.scale;
			r = new Player(randX, randY);
			//captured = false;
		}
	}
	
	public void checkSnakeCollision()
	{
		Player head = snake.getFirst();
		if(head.x > screenWidth-(head.width) || 
		   head.y > screenHeight-(head.height) ||
		   head.x < 0 || 
		   head.y < 0){
			gameOver = true;
		}
		
//		for(Player segment : snake)
//		{
//			if(segment != head)
//			{
//				if(collision(head, segment))
//				{
//					gameOver = true;
//				}	
//			}
//		}
	}
	
	public boolean collision(Player p, Player r)
	{
		return p.x < r.x + r.width &&
			   p.x + p.width > r.x &&
			   p.y < r.y + r.height &&
			   p.y + p.height > r.y;
	}
	
	public int getXforCenteredText(String text, Graphics g) {
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        return screenWidth / 2 - length / 2; // Center the text horizontally
    }
	
	 // Reset the game
    public void resetGame() {
        gameLoop.stop();

        // Clear all rocks and reset score, player position, etc.
        snake.clear();
        snake.add(new Player(px, py));
        score = 0;
        gameOver = false;
        
        upPressed = false;
        downPressed = false;
        leftPressed = false;
        rightPressed = false;
        dy = 0;
        dx = 0;

        r = null;
        // Restart timers
        gameLoop.start();
    }
	
	public class Player{
		int x,y;
		int width = pWidth,height = pHeight;
		public Player(int x, int y)
		{
			this.x = x;
			this.y = y;
		}
	}
//	
//	public class Red{
//		int x,y;
//		int width = rWidth,height = rHeight;
//		public Red(int x, int y)
//		{
//			this.x = x;
//			this.y = y;
//		}
//	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		move();
		repaint();
	}
}
