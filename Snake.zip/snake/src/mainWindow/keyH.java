package mainWindow;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import mainWindow.mechanics.Player;

public class keyH implements KeyListener{

	mechanics m;
	
	public keyH(mechanics m)
	{
		this.m = m;
	}
	
	
	@Override
	public void keyTyped(KeyEvent e) { }

	@Override
	public void keyPressed(KeyEvent e) {
		
		int keyCode = e.getKeyCode();
		if(!m.gameOver)
		{
			if(keyCode == KeyEvent.VK_UP){ m.upPressed = true; m.downPressed = false; m.rightPressed = false; m.leftPressed = false;}
			else if(keyCode == KeyEvent.VK_LEFT){ m.upPressed = false; m.downPressed = false; m.rightPressed = false; m.leftPressed = true;}
			else if(keyCode == KeyEvent.VK_RIGHT){ m.upPressed = false; m.downPressed = false; m.rightPressed = true; m.leftPressed = false;}
			else if(keyCode == KeyEvent.VK_DOWN){ m.upPressed = false; m.downPressed = true; m.rightPressed = false; m.leftPressed = false;}
		}else
		{
			if(keyCode == KeyEvent.VK_ENTER){ m.resetGame();}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
//		if(e.getKeyCode() == KeyEvent.VK_UP){ m.upPressed = false;}
//		else if(e.getKeyCode() == KeyEvent.VK_LEFT){ m.leftPressed = false;}
//		else if(e.getKeyCode() == KeyEvent.VK_RIGHT){ m.rightPressed = false;}
//		else if(e.getKeyCode() == KeyEvent.VK_DOWN){ m.downPressed = false;}
	}

}
