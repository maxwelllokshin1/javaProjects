package calc;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;

public class calc {
	private int answer;
	private Stack<String> s;
	private Queue<String> postFix;
	private Stack<String> solve;
	private int parenthesis;
	public calc()
	{
		answer = 0;
		s = new Stack<>();
		solve = new Stack<>();
		postFix = new LinkedList<>();
		parenthesis = 0;
	}

	public String[] fixData(String[] inFix)
	{
		
		
		for(int i = 0; i<inFix.length; i++)
		{
			if(isOperator(inFix[i]))
			{
				
				checkPriority(inFix, i);
				
				
				s.push(inFix[i]);
			}else if(inFix[i].equals("("))
			{
				parenthesis = 1; 
			}else
			{
				postFix.add(inFix[i]);
			}
		}
		while(!s.isEmpty())
		{
			postFix.add(s.pop());
		}
		
		String[] newPostFix = convert(inFix.length);
		
		return newPostFix;
	}
	
	public void checkPriority(String[] inFix, int i)
	{
		if(!s.isEmpty()) {
			if(s.peek().equals("-") || s.peek().equals("+"))
			{
				if(!inFix[i].equals("*") && !inFix[i].equals("/"))
				{
					postFix.add(s.pop());
				}
			}else
			{
				postFix.add(s.pop());
				checkPriority(inFix, i);
			}
		}
	}
	
	public String[] convert(int length)
	{
		String[] newPostFix = new String[length];
		int i = 0;
		while(!postFix.isEmpty())
		{
			newPostFix[i] = postFix.poll();
			i++;
		}
		
		return newPostFix;
	}
	
	public boolean isOperator(String str) {
        Set<String> operators = new HashSet<>();
        operators.add("+");
        operators.add("-");
        operators.add("*");
        operators.add("/");
        operators.add("%");
        operators.add("++");
        operators.add("--");
        operators.add("=");
        
        return operators.contains(str);
    }
	
	public void solve(String[] postFix)
	{
		if(!solve.isEmpty())
		{
			System.out.println("NO DATA");
		}else
		{
			for(int i = 0; i<postFix.length; i++)
			{
				if(isOperator(postFix[i]))
				{
					int val2 = Integer.parseInt(solve.pop());
					int val1 = Integer.parseInt(solve.pop());
					
					switch(postFix[i])
					{
					case "+":
						solve.push(Integer.toString(val1+val2));
						break;
					case "-":
						solve.push(Integer.toString(val1-val2));
						break;
					case "*":
						solve.push(Integer.toString(val1*val2));
						break;
					case "/":
						solve.push(Integer.toString(val1/val2));
						break;
					}
					
				}else
				{
					solve.push(postFix[i]);
				}
			}
			
			answer = Integer.parseInt(solve.pop());
		}
		
	}
	
	public int getAnswer()
	{
		return answer;
	}
}
