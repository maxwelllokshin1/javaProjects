package calc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class calcTest {
	public static String readFile(String fname)
	{
		BufferedReader br = null;
		String data = null;
		try
		{
			br = new BufferedReader(new FileReader(fname));
			if((data = br.readLine()) != null)
			{
				return data;
			}
		}catch(IOException e)
		{
			e.printStackTrace();
		}finally
		{
			try
			{
				if(br != null)
				{
					br.close();
				}
			}catch(IOException e)
			{
					e.printStackTrace();
			}
		}
		
		return data;
		
	}
	
	public static void main(String[] args)
	{
		String data = readFile("src/calc/data.txt");
		
		if(data == null)
		{
			System.out.println("No Data Found");
			return;
		}else
		{
			System.out.println(data);
		}
		
		String[] inFix = data.split(" ");
		calc c = new calc();
		
		String[] postFix = c.fixData(inFix);
		
		for(int i =0; i<inFix.length; i++)
		{
			System.out.print(postFix[i] + " ");
		}
		System.out.println();
		
		c.solve(postFix); 
		System.out.println("ANSWER: " + c.getAnswer());
	}
}
