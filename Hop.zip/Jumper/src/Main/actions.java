package Main;

import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class actions implements ActionListener, KeyListener {
    private LJumperGame ljg;
    public boolean isPaused = false;

    public actions(LJumperGame ljg) {
        this.ljg = ljg;

    }

    @Override
    public void keyPressed(KeyEvent e) {
    	if(e.getKeyCode() == KeyEvent.VK_SPACE)
    	{
    		if(ljg.screen == ljg.pauseGameScreen)
        	{
        		playGame();
        	}else if(ljg.screen == ljg.gameScreen)
        	{
        		pauseGame();
        	}
    	}
    	
        if (ljg.screen == ljg.gameScreen) {
            int keyCode = e.getKeyCode();

            // Handle movement (UP, LEFT, RIGHT, DOWN)
            if (keyCode == KeyEvent.VK_W) {
                ljg.upPressed = true;
            } else if (keyCode == KeyEvent.VK_A) {
            	ljg.leftPressed = true;
                ljg.velocityX = -10;
            } else if (keyCode == KeyEvent.VK_D) {
            	ljg.rightPressed = true;
                ljg.velocityX = 10;
            } else if (keyCode == KeyEvent.VK_S) {
                ljg.velocityY += 5;  // Add downward velocity when DOWN key is pressed
                ljg.downPressed = true;
            }
        }

        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            if (ljg.screen == ljg.gameStartScreen) {
                ljg.placeAllRocks.start();
                ljg.gameLoop.start();
                ljg.screen = ljg.gameScreen;
            }
            if (ljg.screen == ljg.gameOverScreen) {
                resetGame();  // Reset the game on ENTER from the Game Over screen
            }
        }
        
	        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!isPaused && !ljg.gameOver) {
            ljg.move();  // Move the player and update the game state
        }
        ljg.repaint();  // Redraw the screen
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // No action needed on key typed in this game context
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Handle key release for stopping movements
    	if(ljg.screen == ljg.gameScreen)
    	{
    		if (e.getKeyCode() == KeyEvent.VK_W) {
                ljg.upPressed = false;
            } else if (e.getKeyCode() == KeyEvent.VK_S) {
                ljg.downPressed = false;
                ljg.velocityY = 0;  // Reset downward velocity when DOWN is released
            } else if (e.getKeyCode() == KeyEvent.VK_A || e.getKeyCode() == KeyEvent.VK_D) {
            	ljg.leftPressed = false;
            	ljg.rightPressed = false;
                ljg.velocityX = 0;  // Stop horizontal movement when arrow keys are released
            }
    	}
    }

    // Reset the game
    public void resetGame() {
    	ljg.placeAllRocks.stop();
    	ljg.gameLoop.stop();
        // Clear all rocks and reset score, player position, etc.
        ljg.plats.clear();
        ljg.score = 0;
        ljg.jumped = 0;
        ljg.velocityY = 0;
        ljg.velocityX = 0;
        ljg.screen = ljg.gameScreen;
        ljg.gameOver = false;
        ljg.velocityDelta = -23;
        ljg.platGrav = 5;
        
        ljg.upPressed = false;
        ljg.downPressed = false;
        // Reinitialize player (null indicates the player needs to be created again)
        ljg.p = null;

        // Restart timers
        ljg.gameLoop.start();
        ljg.placeAllRocks.start();
    }
    
    public void pauseGame()
    {
    	isPaused = true;
        ljg.screen = ljg.pauseGameScreen;
        ljg.repaint();
        ljg.gameLoop.stop();
        
    }
    
    public void playGame()
    {
    	isPaused = false;
        ljg.screen = ljg.gameScreen;
        ljg.gameLoop.start();
        ljg.repaint();
    }
}