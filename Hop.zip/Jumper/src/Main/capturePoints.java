package Main;

public class capturePoints {

}
