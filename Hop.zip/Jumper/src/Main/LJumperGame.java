package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class LJumperGame extends JPanel implements ActionListener {
	public boolean upPressed, leftPressed, rightPressed, downPressed;
	public final int screenWidth = mainWindow.screenWidth;
	public final int screenHeight = mainWindow.screenHeight;

	// PLAYER
	public final int pWidth = mainWindow.tile, pHeight = pWidth;
	public int px, py;

	// ROCK
	public final int rWidth = mainWindow.tile, rHeight = rWidth;
	public int platGrav = 5;

	// LOGIC
	public Player p;
	public int velocityX = 0, velocityY = 0, gravity = 1;

	public LinkedList<Plat> plats;

	// TIME
	public Timer gameLoop;
	public Timer placeAllRocks;

	public int score = 0;
	public boolean gameOver = false;
	public int jumped = 0;

	// GAME SCREENS
	public int screen = 0;
	public int gameStartScreen = 0, optionsScreen = 1, gameScreen = 2, gameOverScreen = 3, pauseGameScreen = 4;

	public int FPS = 60;

	actions a;
	ScreenManager screenManager;
	
		// IMAGE
	BufferedImage lilyPad1, lilyPad2, lilyPad3, lilyPadShadow;
	BufferedImage froggy, bg;
	
	int velocityDelta = -23;
	public LJumperGame() {
		screen = gameStartScreen;
		setPreferredSize(new Dimension(screenWidth, screenHeight));
		setBackground(Color.black);
		setFocusable(true);
		
		lilyPad1 = setup("lilyPad1");
		lilyPad2 = setup("lilyPad2");
		lilyPad3 = setup("lilyPad3");
		lilyPadShadow = setup("lilyPadShadow");
		froggy = setup("froggy");
		bg = setup("background");
		
		a = new actions(this);
		addKeyListener(a);

		// Mouse Listeners
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				LJumperGame.this.mousePressed(e); // Handle mouse press (e.g., restart game)
			}

//            @Override
//            public void mouseReleased(MouseEvent e) {
//                LJumperGame.this.mouseReleased(e);  // Handle mouse press (e.g., restart game)
//            }
		});

		plats = new LinkedList<>();

		// Timer for placing rocks
		placeAllRocks = new Timer(100, e -> placePlats());

		// Main game loop timer
		gameLoop = new Timer(1000 / FPS, this);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		screenManager = new ScreenManager(g, this);
		// Render different screens based on the current state
		if (screen == gameStartScreen) {
			screenManager.TitleUI();
		} else if (screen == gameScreen) {
			drawGameScreen(g);
		} else if (screen == gameOverScreen) {
			screenManager.EndUI();
		} else if (screen == pauseGameScreen) {
			drawGameScreen(g);
			screenManager.PauseUI();
		}
	}

	private void drawGameScreen(Graphics g) {
        g.drawImage(bg, 0, 0, screenWidth, screenHeight, null);  // Use BufferedImage directly

        for (Plat platform : plats) {
            g.drawImage(platform.img, platform.x, platform.y, platform.width, platform.height, null);  // Use BufferedImage directly
        }

        if (p != null) {  // Only draw the player if p is not null
            g.drawImage(p.img, p.x, p.y, p.width, p.height, null);  // Use BufferedImage directly
        }
    }
	Plat firstPlat = null;
	boolean onPlat = false;
	public void move() {
	    if (jumped == 0 && !plats.isEmpty()) {
	    	firstPlat = plats.getFirst();
	        if (p == null) {
	            p = new Player(firstPlat.x,
	            		firstPlat.y, froggy);
	            jumped = 0;
	        }
	        p.y = firstPlat.y;
	        if (!collision(p, firstPlat) || downPressed) {
	        	jumped = 1;
	            velocityY = platGrav;
	        }
	    }

	    if (p != null) {

	        velocityY += gravity;
	        p.y += velocityY;

	        if (jumped != 0) {
	            if (p.y + pHeight < 0) {
	                gameOver = true;
	                screen = gameOverScreen;
	                return;
	            }
	        }else
	        {
	        	jumped = 0;
	        }

	        p.x += velocityX;

	        // Keep player within bounds
	        if (p.x > screenWidth) p.x = 0;
	        if (p.x < 0) p.x = screenWidth - pWidth;

	        Iterator<Plat> rockIterator = plats.iterator();
	        while (rockIterator.hasNext()) {
	        	Plat curPlat = rockIterator.next();
	        	curPlat.y += platGrav;
	            if (collision(p, curPlat)) {
	                velocityY = platGrav;
	                if(p.y == curPlat.y)
	                {
	                	gravity = 0;
	                	onPlat = true;
	                }

	                if (upPressed && p.y > 0) {
	                    if (!curPlat.passed) {
	                        score++;
	                        if(score % 10 == 0)
	                        {
	                        	platGrav += 2;
	                        	velocityDelta -= 3;
	                        	
	                        }
	                    }
	                    jumped = 1;
	                    curPlat.passed = true;
	                    velocityY = velocityDelta; // Jump
	                    onPlat = false;
	                    
	                }else if(leftPressed || rightPressed)
	                {
	                	onPlat = false;
	                }
	            }

	            // Remove off-screen rocks
	            if (curPlat.y > screenHeight) {
	                rockIterator.remove();
	            }
	        }
	        
	        if(!onPlat)
	        {
	        	gravity = 1;
	        }

	        // Check if the player has fallen off the screen
	        if (p.y > screenHeight) {
	            gameOver = true;
	            screen = gameOverScreen;
	            return;
	        }
	    }
	}
	private int randLilyPad;
	private BufferedImage randLilyImg;
	int randX;
	private void placePlats() {
		if (plats.isEmpty() || plats.getLast().y >= screenHeight / 4) {
			randLilyPad = (int) (Math.random() * 3);
			switch(randLilyPad)
			{
			case 0:
				randLilyImg = lilyPad1;
				break;
			case 1:
				randLilyImg = lilyPad2;
				break;
			case 2:
				randLilyImg = lilyPad3;
				break;
			}
			randX = (int) (Math.random() * (screenWidth - rWidth));
			plats.add(new Plat(randX, -rHeight, randLilyImg)); // Place new rock
		}
	}

	private boolean collision(Player p, Plat r) {
		return (p.x+15) < r.x + r.width && (p.x-15) + p.width > r.x && (p.y+15) < r.y + r.height && (p.y-15) + p.height > r.y;
	}

	// Mouse Event Handling
	private void mousePressed(MouseEvent e) {
		int mouseX = e.getX() / mainWindow.tile;
		int mouseY = e.getY() / mainWindow.tile;

		if (screen == gameScreen) {
			//checkRock(mouseX, mouseY);
		}
		System.out.println(mouseX + " " + mouseY);
	}

//	private void checkRock(int mouseX, int mouseY) {
//		Iterator<Plat> rockIterator = plats.iterator();
//		while (rockIterator.hasNext()) {
//			Plat rock = rockIterator.next();
//		}
//	}

	// Player class
	class Player {
		int x, y;
		int width = pWidth, height = pHeight;
		BufferedImage img;
		Player(int x, int y, BufferedImage img) {
			this.x = x;
			this.y = y;
			this.img = img;
		}
	}

	// Rock class
	class Plat {
		int x, y;
		int width = rWidth, height = rHeight;
		boolean passed = false;
		BufferedImage img;
		Plat(int x, int y, BufferedImage img) {
			this.x = x;
			this.y = y;
			this.img = img;
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(screen != gameOverScreen)
		{
			a.actionPerformed(e);
		}
		repaint(); // Redraw the screen
	}
	
	
	public BufferedImage scaleImage(BufferedImage original, int width, int height)
	{
		BufferedImage scaledImage = new BufferedImage(width, height, original.getType());
		Graphics2D g2 = scaledImage.createGraphics();
		g2.drawImage(original, 0, 0, width, height, null);
		g2.dispose();
		
		return scaledImage;
	}
    
    public BufferedImage setup(String imagePath)
	{
		BufferedImage image = null;
		try
		{
			image = ImageIO.read(getClass().getResourceAsStream(imagePath+".png"));
			image = scaleImage(image, 16, 16);
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		return image;
	}
}