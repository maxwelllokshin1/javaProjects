package Main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class ScreenManager {

	Graphics g;
	LJumperGame ljg;
	
    String text;
	
	public ScreenManager(Graphics g, LJumperGame ljg)
	{
		this.g = g;
		this.ljg = ljg;
		text = "";
	}
	
	int adjust = mainWindow.tile;
	
	public void TitleUI()
	{
		int deltaY = ljg.screenHeight/8;
		//Color c = new Color(255, 255, 255, 50);		
		createText(text,0, new Color(255, 255, 255, 50), ljg.screenWidth/8, deltaY);
		deltaY = ljg.screenHeight/3;
		deltaY = createText("HOP",30, new Color(0, 155, 255, 255), ljg.screenWidth/2, deltaY);
		deltaY = createText("PLAY GAME",30, new Color(255, 255, 255, 50), (ljg.screenWidth/4) - (ljg.screenWidth/16), deltaY);
		deltaY = createText("OPTIONS",30, new Color(255, 255, 255, 50), (ljg.screenWidth/4) - (ljg.screenWidth/16), deltaY);
		deltaY = createText("EXIT",30, new Color(255, 255, 255, 50), (ljg.screenWidth/4) - (ljg.screenWidth/16), deltaY);
		
		
		
//		g.setColor(Color.GRAY);
//		g.setFont(g.getFont().deriveFont(Font.PLAIN, 30F));
//		text = "HOP";
//		g.drawString(text, getXforCenteredText(text), ljg.screenHeight/2);
//		
//		g.setFont(g.getFont().deriveFont(Font.PLAIN, 20F));
//		text = "[Press ENTER]";
//		g.drawString(text, getXforCenteredText(text), ljg.screenHeight/2 + adjust);
		
		
	}
	
	public void EndUI()
	{
//		g.setColor(Color.GRAY);
//		g.setFont(g.getFont().deriveFont(Font.PLAIN, 30F));
//		text = "Game Over: " + String.valueOf((int) ljg.score);
//		g.drawString(text, getXforCenteredText(text), ljg.screenHeight/2);
//		g.setFont(g.getFont().deriveFont(Font.PLAIN, 20F));
//		text = "[Press ENTER]";
//		g.drawString(text, getXforCenteredText(text), ljg.screenHeight/2 + (50));
		
		int deltaY = ljg.screenHeight/8;
		Color c = new Color(255, 255, 255, 50);		
		createText("",0, c, ljg.screenWidth/8, deltaY);
		deltaY = ljg.screenHeight/3;
		deltaY = createText("YOU LOSE",30, new Color(0, 155, 255, 255), ljg.screenWidth/2, deltaY);
		deltaY = createText("Game Over: " + String.valueOf((int)ljg.score),30, c, (ljg.screenWidth/4) - (ljg.screenWidth/16), deltaY);
		//deltaY = createText("OPTIONS",30, c, ljg.screenWidth/4, deltaY);
		deltaY = createText("EXIT",30, c, (ljg.screenWidth/4) - (ljg.screenWidth/16), deltaY);
	}
	
	public void PauseUI()
	{
		Color c = new Color(255, 255, 255, 150);
		g.setColor(c);
		g.setFont(g.getFont().deriveFont(Font.PLAIN, 30F));
		text = "PAUSED";
		g.drawString(text, getXforCenteredText(text), ljg.screenHeight/2);
	}
	
	public int getXforCenteredText(String text) {
        int length = (int) g.getFontMetrics().getStringBounds(text, g).getWidth();
        return ljg.screenWidth / 2 - length / 2; // Center the text horizontally
    }
	
	public int createText(String t, int fNum, Color c, int x, int y)
	{
		g.setFont(g.getFont().deriveFont(Font.PLAIN, fNum));
		g.setColor(c);
		g.drawString(t, getXforCenteredText(t), y+(adjust -(adjust/4)));
		if(t == "")
		{
			g.fillRoundRect(x, y, ljg.screenWidth - (x*2) , ljg.screenHeight - (y*2), 15, 15);
		}else
		{
			g.fillRoundRect(x, y, ljg.screenWidth - (x*2) , adjust, adjust, adjust);
		}
		return y+(adjust*2);
	}
	
	
}
